<?php

return array(
    'embed.synced' => 'Synced',
    'embed.failed' => 'Sync failed',
);
