<?php

return array(
    'embed.synced' => 'Synchronisé',
    'embed.failed' => 'Échec de synchronisation',
);
